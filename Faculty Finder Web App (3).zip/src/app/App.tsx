import { useState, useEffect } from 'react';
import StudentPage from './components/StudentPage';
import LoginPage from './components/LoginPage';
import DashboardPage from './components/DashboardPage';

export default function App() {
  const [currentRoute, setCurrentRoute] = useState('home');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      setCurrentRoute(hash || 'home');
    };

    window.addEventListener('hashchange', handleHashChange);
    handleHashChange();

    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderPage = () => {
    switch (currentRoute) {
      case '/login':
        return <LoginPage />;
      case '/dashboard':
        return <DashboardPage />;
      default:
        return <StudentPage />;
    }
  };

  return <div className="size-full">{renderPage()}</div>;
}