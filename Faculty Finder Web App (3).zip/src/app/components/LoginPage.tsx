import { useState } from 'react';
import { loginFaculty } from '../utils/facultyData';

export default function LoginPage() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const faculty = loginFaculty(username, password);
    if (faculty) {
      sessionStorage.setItem('loggedInFaculty', faculty.id);
      window.location.hash = '/dashboard';
    } else {
      setError('Invalid username or password');
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left Side - Dark Blue */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-to-br from-blue-950 via-blue-900 to-blue-800 p-16 flex-col justify-between">
        <div className="flex items-center gap-3 text-white">
          <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
            <span className="font-bold text-xl">FF</span>
          </div>
          <div>
            <div className="font-bold text-lg">Faculty Finder</div>
            <div className="text-xs text-blue-200">Faculty Edition</div>
          </div>
        </div>

        <div>
          <h1 className="text-5xl font-serif mb-6">
            <span className="text-white">Welcome back,</span>
            <br />
            <span className="italic text-blue-300">professor.</span>
          </h1>
          <p className="text-blue-200 text-lg max-w-md leading-relaxed">
            Manage your class schedule, update availability and timetable — so students always know when to find you.
          </p>
        </div>

        <div className="text-blue-300 text-sm">
          © 2026 Faculty Finder. All rights reserved.
        </div>
      </div>

      {/* Right Side - White */}
      <div className="flex-1 flex items-center justify-center p-8 bg-gray-50">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <a href="#/" className="text-sm text-gray-600 hover:text-gray-900 mb-8 inline-block">
              ← Back to student page
            </a>
            <h2 className="text-4xl font-serif mt-6 mb-2">Faculty Sign in</h2>
            <p className="text-gray-500">Log into manage your account and schedule</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-sm text-gray-600 mb-2">
                Username or email address
              </label>
              <input
                id="username"
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                placeholder="Enter your username"
                required
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-sm text-gray-600 mb-2">
                Password
              </label>
              <input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
                placeholder="Enter your password"
                required
              />
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gray-900 hover:bg-gray-800 text-white py-3 rounded-full font-medium transition-colors"
            >
              Sign in
            </button>
          </form>

          {/* Demo Credentials */}
          <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm font-semibold text-gray-900 mb-2">Demo Credentials:</p>
            <div className="text-sm text-gray-700 space-y-1">
              <p><span className="font-medium">Username:</span> rajesh, priya, amit, neha, vikram, etc.</p>
              <p><span className="font-medium">Password:</span> pass123 (for all)</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
