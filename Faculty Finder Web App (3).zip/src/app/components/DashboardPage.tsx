import { useState, useEffect } from 'react';
import { LogOut } from 'lucide-react';
import { getFacultyData, updateFacultyTimetable, updateFacultyCabin, DAYS, getCurrentStatus, type Faculty } from '../utils/facultyData';

const TIME_SLOTS = [
  '09:00-10:00',
  '10:00-11:00',
  '11:00-12:00',
  '12:00-13:00',
  '14:00-15:00',
  '15:00-16:00',
  '16:00-17:00',
  '17:00-18:00',
];

export default function DashboardPage() {
  const [faculty, setFaculty] = useState<Faculty | null>(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [editingProfile, setEditingProfile] = useState(false);
  const [profileData, setProfileData] = useState({ name: '', department: '', subject: '', cabin: '' });
  const [timetableData, setTimetableData] = useState<Record<string, Record<string, string>>>({});

  useEffect(() => {
    const facultyId = sessionStorage.getItem('loggedInFaculty');
    if (!facultyId) {
      window.location.hash = '/login';
      return;
    }

    const allFaculty = getFacultyData();
    const currentFaculty = allFaculty.find(f => f.id === facultyId);
    if (currentFaculty) {
      setFaculty(currentFaculty);
      setProfileData({
        name: currentFaculty.name,
        department: currentFaculty.department,
        subject: currentFaculty.subject,
        cabin: currentFaculty.cabin
      });

      // Convert timetable array to grid format
      const gridData: Record<string, Record<string, string>> = {};
      currentFaculty.timetable.forEach(slot => {
        const timeKey = `${slot.startTime}-${slot.endTime}`;
        if (!gridData[timeKey]) gridData[timeKey] = {};
        gridData[timeKey][slot.day] = `${slot.subject} — ${slot.classroom}`;
      });
      setTimetableData(gridData);
    }

    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleLogout = () => {
    sessionStorage.removeItem('loggedInFaculty');
    window.location.hash = '/login';
  };

  const handleSaveProfile = () => {
    if (faculty) {
      updateFacultyCabin(faculty.id, profileData.cabin);
      setFaculty({ ...faculty, ...profileData });
      setEditingProfile(false);
    }
  };

  const handleCellChange = (timeSlot: string, day: string, value: string) => {
    setTimetableData(prev => ({
      ...prev,
      [timeSlot]: {
        ...prev[timeSlot],
        [day]: value
      }
    }));
  };

  const handleSaveTimetable = () => {
    if (!faculty) return;

    const newTimetable = [];
    for (const [timeSlot, days] of Object.entries(timetableData)) {
      const [startTime, endTime] = timeSlot.split('-');
      for (const [day, content] of Object.entries(days)) {
        if (content && content.trim()) {
          const parts = content.split('—').map(p => p.trim());
          const subject = parts[0] || content;
          const classroom = parts[1] || 'TBA';

          newTimetable.push({
            id: `${day}-${timeSlot}-${Date.now()}`,
            day,
            startTime,
            endTime,
            subject,
            classroom
          });
        }
      }
    }

    updateFacultyTimetable(faculty.id, newTimetable);
    setFaculty({ ...faculty, timetable: newTimetable });
    alert('Timetable saved successfully!');
  };

  const handleClearAll = () => {
    if (window.confirm('Are you sure you want to clear all timetable data?')) {
      setTimetableData({});
    }
  };

  if (!faculty) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-gray-600">Loading...</div>
      </div>
    );
  }

  const { status, details } = getCurrentStatus(faculty);
  const initials = faculty.name.split(' ').map(n => n[0]).join('').slice(0, 2);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">FF</span>
                </div>
                <div>
                  <div className="font-bold text-gray-900">Faculty <span className="italic text-blue-600">Finder</span></div>
                  <div className="text-xs text-gray-500 uppercase tracking-wide">Faculty Dashboard</div>
                </div>
              </div>

              <div className="ml-4 flex items-center gap-2 px-3 py-1 bg-green-100 rounded-full">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs font-medium text-green-700">Live</span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-sm">{initials}</span>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-900">{faculty.name}</div>
                  <div className="text-xs text-gray-500">{faculty.department}</div>
                </div>
              </div>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm font-medium">Logout</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Greeting and Time Widget */}
        <div className="flex justify-between items-start mb-8">
          <div>
            <h1 className="text-4xl font-serif mb-2">
              Hello, <span className="italic text-blue-600">{faculty.name.split(' ')[faculty.name.split(' ').length - 1]}</span>
            </h1>
            <p className="text-gray-600">Manage your availability and timetable below.</p>
          </div>

          {/* Time Widget */}
          <div className="bg-white border-2 border-gray-200 rounded-xl p-4 min-w-[240px]">
            <div className="text-xs text-gray-500 uppercase tracking-wide mb-2">
              {currentTime.toLocaleDateString('en-US', { weekday: 'long' })}
            </div>
            <div className="text-4xl font-bold text-gray-900 mb-2">
              {currentTime.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false })}
            </div>
            <div className="text-sm text-gray-600">
              Slot: <span className="font-semibold">{details || 'No active slot'}</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Profile & Cabin */}
          <div className="bg-white border-2 border-gray-200 rounded-xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-serif">Profile & cabin</h2>
              {!editingProfile && (
                <button
                  onClick={() => setEditingProfile(true)}
                  className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                >
                  Edit profile
                </button>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-500 uppercase tracking-wide mb-2">Name</label>
                {editingProfile ? (
                  <input
                    type="text"
                    value={profileData.name}
                    onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  />
                ) : (
                  <div className="font-semibold text-gray-900">{faculty.name}</div>
                )}
              </div>

              <div>
                <label className="block text-xs text-gray-500 uppercase tracking-wide mb-2">Department</label>
                {editingProfile ? (
                  <input
                    type="text"
                    value={profileData.department}
                    onChange={(e) => setProfileData({ ...profileData, department: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  />
                ) : (
                  <div className="font-semibold text-gray-900">{faculty.department}</div>
                )}
              </div>

              <div>
                <label className="block text-xs text-gray-500 uppercase tracking-wide mb-2">Subject</label>
                {editingProfile ? (
                  <input
                    type="text"
                    value={profileData.subject}
                    onChange={(e) => setProfileData({ ...profileData, subject: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  />
                ) : (
                  <div className="font-semibold text-gray-900">{faculty.subject}</div>
                )}
              </div>

              <div>
                <label className="block text-xs text-gray-500 uppercase tracking-wide mb-2">Cabin Number</label>
                {editingProfile ? (
                  <input
                    type="text"
                    value={profileData.cabin}
                    onChange={(e) => setProfileData({ ...profileData, cabin: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  />
                ) : (
                  <div className="font-semibold text-gray-900">{faculty.cabin}</div>
                )}
              </div>

              {editingProfile && (
                <div className="flex gap-2 pt-4">
                  <button
                    onClick={handleSaveProfile}
                    className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors"
                  >
                    Save profile
                  </button>
                  <button
                    onClick={() => {
                      setEditingProfile(false);
                      setProfileData({
                        name: faculty.name,
                        department: faculty.department,
                        subject: faculty.subject,
                        cabin: faculty.cabin
                      });
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Availability Status */}
          <div className="bg-white border-2 border-gray-200 rounded-xl p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-serif">Availability status</h2>
              <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
                Manual override
              </button>
            </div>

            <p className="text-sm text-gray-600 mb-4">
              Auto-status shows "In Class" when your timetable has a class now. You can manually mark yourself as Available or Busy.
            </p>

            <div className="grid grid-cols-2 gap-3 mb-6">
              <button className="px-4 py-3 bg-green-100 text-green-700 rounded-lg border-2 border-green-300 font-medium hover:bg-green-200 transition-colors">
                Available
              </button>
              <button className="px-4 py-3 bg-white text-gray-700 rounded-lg border-2 border-gray-300 font-medium hover:bg-gray-50 transition-colors">
                Busy
              </button>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <div className="text-xs text-gray-500 uppercase tracking-wide mb-2">Current live status</div>
              <div className="text-2xl font-serif">{status}</div>
              {details && (
                <div className="text-sm text-gray-600 mt-1">{details}</div>
              )}
            </div>
          </div>
        </div>

        {/* Weekly Timetable */}
        <div className="bg-white border-2 border-gray-200 rounded-xl p-6">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-xl font-serif mb-1">Weekly timetable</h2>
              <p className="text-sm text-gray-600">Type the subject/class name in any cell. The current slot is highlighted.</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={handleClearAll}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2"
              >
                <span className="text-sm">Clear all</span>
              </button>
              <button
                onClick={handleSaveTimetable}
                className="px-4 py-2 bg-gray-900 text-white rounded-lg hover:bg-gray-800 transition-colors flex items-center gap-2"
              >
                <span className="text-sm">Save timetable</span>
              </button>
            </div>
          </div>

          {/* Timetable Grid */}
          <div className="overflow-x-auto">
            <table className="w-full border-collapse">
              <thead>
                <tr>
                  <th className="border-2 border-gray-300 bg-gray-100 px-4 py-3 text-left text-sm font-semibold text-gray-700 uppercase tracking-wide">
                    Time / Day
                  </th>
                  {DAYS.map(day => (
                    <th
                      key={day}
                      className="border-2 border-gray-300 bg-blue-50 px-4 py-3 text-center text-sm font-semibold text-gray-700 uppercase tracking-wide"
                    >
                      {day}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {TIME_SLOTS.map(timeSlot => (
                  <tr key={timeSlot}>
                    <td className="border-2 border-gray-300 bg-gray-50 px-4 py-3 text-sm font-medium text-gray-700 whitespace-nowrap">
                      {timeSlot}
                    </td>
                    {DAYS.map(day => (
                      <td key={day} className="border-2 border-gray-300 p-1">
                        <input
                          type="text"
                          value={timetableData[timeSlot]?.[day] || ''}
                          onChange={(e) => handleCellChange(timeSlot, day, e.target.value)}
                          placeholder="—"
                          className="w-full px-2 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 rounded"
                        />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
