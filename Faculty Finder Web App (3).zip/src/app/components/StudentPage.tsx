import { useState, useEffect } from 'react';
import { Search, Clock } from 'lucide-react';
import { getFacultyData, getCurrentStatus, initializeFacultyData, type Faculty } from '../utils/facultyData';

const DEPT_COLORS: Record<string, { bg: string; text: string; border: string }> = {
  'Computer Science': { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200' },
  'Electronics': { bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-200' },
  'Mechanical': { bg: 'bg-orange-50', text: 'text-orange-700', border: 'border-orange-200' },
  'Civil': { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
  'Mathematics': { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200' },
  'Physics': { bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-200' },
};

const DEPT_ABBR: Record<string, string> = {
  'Computer Science': 'CS',
  'Electronics': 'EN',
  'Mechanical': 'MN',
  'Civil': 'CN',
  'Mathematics': 'MA',
  'Physics': 'PH',
};

export default function StudentPage() {
  const [faculty, setFaculty] = useState<Faculty[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('All');
  const [filteredFaculty, setFilteredFaculty] = useState<Faculty[]>([]);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    initializeFacultyData();
    const data = getFacultyData();
    setFaculty(data);
    setFilteredFaculty(data);

    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const filtered = faculty.filter(f => {
      const matchesSearch = f.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.department.toLowerCase().includes(searchTerm.toLowerCase()) ||
        f.subject.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDept = selectedDept === 'All' || f.department === selectedDept;
      return matchesSearch && matchesDept;
    });
    setFilteredFaculty(filtered);
  }, [searchTerm, selectedDept, faculty]);

  const departments = ['All', ...Array.from(new Set(faculty.map(f => f.department)))];
  const availableCount = faculty.filter(f => getCurrentStatus(f).status === 'Available').length;
  const busyCount = faculty.filter(f => getCurrentStatus(f).status === 'In Class').length;

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-lg">FF</span>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Faculty Finder</h1>
                <p className="text-xs text-gray-500">Find faculty availability</p>
              </div>
            </div>
            <a
              href="#/login"
              className="bg-gray-900 hover:bg-gray-800 text-white px-5 py-2 rounded-full text-sm transition-colors"
            >
              Faculty Login
            </a>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Hero Section */}
        <div className="flex justify-between items-start mb-8">
          <div className="flex-1">
            <h2 className="text-5xl font-serif mb-2">
              Find any faculty.
            </h2>
            <h2 className="text-5xl font-serif italic text-blue-600 mb-4">
              Know if they're free.
            </h2>
            <p className="text-gray-600 max-w-lg">
              Search through our comprehensive faculty directory to find professors, check their real-time availability, and locate their cabin numbers instantly.
            </p>
          </div>

          {/* Clock Widget */}
          <div className="bg-gradient-to-br from-blue-900 to-blue-700 text-white rounded-2xl p-6 w-80 shadow-xl">
            <div className="flex items-center gap-2 mb-4">
              <Clock className="w-5 h-5" />
              <span className="text-sm opacity-90">Current Time</span>
            </div>
            <div className="text-5xl font-bold mb-2">{formatTime(currentTime)}</div>
            <div className="text-sm opacity-75">{formatDate(currentTime)}</div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-6 shadow-sm">
          <div className="flex gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search by name or subject..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white min-w-[200px]"
            >
              {departments.map(dept => (
                <option key={dept} value={dept}>{dept === 'All' ? 'All Departments' : dept}</option>
              ))}
            </select>
          </div>

          {/* Stats */}
          <div className="flex gap-6 text-sm">
            <div>
              <span className="font-bold text-2xl text-gray-900">{faculty.length}</span>
              <span className="text-gray-500 ml-2">Total</span>
            </div>
            <div className="border-l border-gray-300 pl-6">
              <span className="font-bold text-2xl text-green-600">{availableCount}</span>
              <span className="text-gray-500 ml-2">Available</span>
            </div>
            <div className="border-l border-gray-300 pl-6">
              <span className="font-bold text-2xl text-red-600">{busyCount}</span>
              <span className="text-gray-500 ml-2">Busy</span>
            </div>
          </div>
        </div>

        {/* Faculty Directory */}
        <h3 className="text-xl font-semibold text-gray-900 mb-4">Faculty directory</h3>
        <p className="text-sm text-gray-500 mb-6">Browse all faculty members</p>

        {/* Faculty Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredFaculty.map(f => {
            const { status, details } = getCurrentStatus(f);
            const deptColor = DEPT_COLORS[f.department] || DEPT_COLORS['Computer Science'];
            const deptAbbr = DEPT_ABBR[f.department] || 'XX';

            return (
              <div
                key={f.id}
                className="bg-white rounded-xl border-2 border-gray-200 hover:border-blue-400 hover:shadow-lg transition-all duration-200 overflow-hidden"
              >
                {/* Department Header */}
                <div className={`${deptColor.bg} ${deptColor.text} ${deptColor.border} border-b-2 px-4 py-2 flex justify-between items-center`}>
                  <span className="text-xs font-bold">{deptAbbr}</span>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    status === 'In Class'
                      ? 'bg-red-500 text-white'
                      : 'bg-green-500 text-white'
                  }`}>
                    {status === 'In Class' ? 'Busy' : 'Free'}
                  </span>
                </div>

                {/* Faculty Info */}
                <div className="p-4">
                  <h4 className="font-bold text-gray-900 mb-3">{f.name}</h4>

                  <div className="text-sm text-gray-600 space-y-1">
                    <p><span className="font-medium">Subject:</span> {f.subject}</p>
                    <p><span className="font-medium">Cabin:</span> {f.cabin}</p>
                  </div>

                  {details && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <p className="text-xs text-gray-500 mb-1">Currently teaching:</p>
                      <p className="text-sm font-semibold text-blue-700">{details}</p>
                    </div>
                  )}

                  {!details && status === 'Available' && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <p className="text-xs text-green-600 font-medium">Available now</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {filteredFaculty.length === 0 && (
          <div className="text-center py-16 bg-white rounded-xl border border-gray-200">
            <p className="text-gray-500">No faculty members found matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}
