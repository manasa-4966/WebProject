export interface TimeSlot {
  id: string;
  day: string;
  startTime: string;
  endTime: string;
  subject: string;
  classroom: string;
}

export interface Faculty {
  id: string;
  name: string;
  department: string;
  subject: string;
  cabin: string;
  username: string;
  password: string;
  timetable: TimeSlot[];
}

export const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export const INITIAL_FACULTY: Faculty[] = [
  // Computer Science Department (10 faculty)
  { id: '1', name: 'Dr. Rajesh Kumar', department: 'Computer Science', subject: 'Data Structures', cabin: 'CS-101', username: 'rajesh', password: 'pass123', timetable: [] },
  { id: '2', name: 'Prof. Priya Sharma', department: 'Computer Science', subject: 'Algorithms', cabin: 'CS-102', username: 'priya', password: 'pass123', timetable: [] },
  { id: '3', name: 'Dr. Amit Verma', department: 'Computer Science', subject: 'Database Systems', cabin: 'CS-103', username: 'amit', password: 'pass123', timetable: [] },
  { id: '4', name: 'Prof. Neha Singh', department: 'Computer Science', subject: 'Operating Systems', cabin: 'CS-104', username: 'neha', password: 'pass123', timetable: [] },
  { id: '5', name: 'Dr. Vikram Patel', department: 'Computer Science', subject: 'Computer Networks', cabin: 'CS-105', username: 'vikram', password: 'pass123', timetable: [] },
  { id: '6', name: 'Prof. Anjali Reddy', department: 'Computer Science', subject: 'Software Engineering', cabin: 'CS-106', username: 'anjali', password: 'pass123', timetable: [] },
  { id: '7', name: 'Dr. Sanjay Gupta', department: 'Computer Science', subject: 'Artificial Intelligence', cabin: 'CS-107', username: 'sanjay', password: 'pass123', timetable: [] },
  { id: '8', name: 'Prof. Kavita Joshi', department: 'Computer Science', subject: 'Machine Learning', cabin: 'CS-108', username: 'kavita', password: 'pass123', timetable: [] },
  { id: '9', name: 'Dr. Rahul Mehta', department: 'Computer Science', subject: 'Web Development', cabin: 'CS-109', username: 'rahul', password: 'pass123', timetable: [] },
  { id: '10', name: 'Prof. Sunita Rao', department: 'Computer Science', subject: 'Cyber Security', cabin: 'CS-110', username: 'sunita', password: 'pass123', timetable: [] },

  // Electronics Department (10 faculty)
  { id: '11', name: 'Dr. Anil Kumar', department: 'Electronics', subject: 'Digital Electronics', cabin: 'EC-201', username: 'anil', password: 'pass123', timetable: [] },
  { id: '12', name: 'Prof. Meera Desai', department: 'Electronics', subject: 'Microprocessors', cabin: 'EC-202', username: 'meera', password: 'pass123', timetable: [] },
  { id: '13', name: 'Dr. Suresh Nair', department: 'Electronics', subject: 'Signal Processing', cabin: 'EC-203', username: 'suresh', password: 'pass123', timetable: [] },
  { id: '14', name: 'Prof. Rekha Iyer', department: 'Electronics', subject: 'VLSI Design', cabin: 'EC-204', username: 'rekha', password: 'pass123', timetable: [] },
  { id: '15', name: 'Dr. Manish Shah', department: 'Electronics', subject: 'Communication Systems', cabin: 'EC-205', username: 'manish', password: 'pass123', timetable: [] },
  { id: '16', name: 'Prof. Pooja Bansal', department: 'Electronics', subject: 'Embedded Systems', cabin: 'EC-206', username: 'pooja', password: 'pass123', timetable: [] },
  { id: '17', name: 'Dr. Deepak Agarwal', department: 'Electronics', subject: 'Control Systems', cabin: 'EC-207', username: 'deepak', password: 'pass123', timetable: [] },
  { id: '18', name: 'Prof. Shilpa Menon', department: 'Electronics', subject: 'Power Electronics', cabin: 'EC-208', username: 'shilpa', password: 'pass123', timetable: [] },
  { id: '19', name: 'Dr. Ravi Kulkarni', department: 'Electronics', subject: 'Electronic Circuits', cabin: 'EC-209', username: 'ravi', password: 'pass123', timetable: [] },
  { id: '20', name: 'Prof. Divya Pillai', department: 'Electronics', subject: 'Wireless Communication', cabin: 'EC-210', username: 'divya', password: 'pass123', timetable: [] },

  // Mechanical Engineering (10 faculty)
  { id: '21', name: 'Dr. Prakash Yadav', department: 'Mechanical', subject: 'Thermodynamics', cabin: 'ME-301', username: 'prakash', password: 'pass123', timetable: [] },
  { id: '22', name: 'Prof. Lakshmi Nair', department: 'Mechanical', subject: 'Fluid Mechanics', cabin: 'ME-302', username: 'lakshmi', password: 'pass123', timetable: [] },
  { id: '23', name: 'Dr. Ashok Jain', department: 'Mechanical', subject: 'Manufacturing', cabin: 'ME-303', username: 'ashok', password: 'pass123', timetable: [] },
  { id: '24', name: 'Prof. Sneha Varma', department: 'Mechanical', subject: 'CAD/CAM', cabin: 'ME-304', username: 'sneha', password: 'pass123', timetable: [] },
  { id: '25', name: 'Dr. Ramesh Bhat', department: 'Mechanical', subject: 'Machine Design', cabin: 'ME-305', username: 'ramesh', password: 'pass123', timetable: [] },
  { id: '26', name: 'Prof. Usha Shetty', department: 'Mechanical', subject: 'Robotics', cabin: 'ME-306', username: 'usha', password: 'pass123', timetable: [] },
  { id: '27', name: 'Dr. Kiran Rao', department: 'Mechanical', subject: 'Automobile Engineering', cabin: 'ME-307', username: 'kiran', password: 'pass123', timetable: [] },
  { id: '28', name: 'Prof. Geeta Krishnan', department: 'Mechanical', subject: 'Heat Transfer', cabin: 'ME-308', username: 'geeta', password: 'pass123', timetable: [] },
  { id: '29', name: 'Dr. Mohan Das', department: 'Mechanical', subject: 'Materials Science', cabin: 'ME-309', username: 'mohan', password: 'pass123', timetable: [] },
  { id: '30', name: 'Prof. Radha Hegde', department: 'Mechanical', subject: 'Industrial Engineering', cabin: 'ME-310', username: 'radha', password: 'pass123', timetable: [] },

  // Civil Engineering (10 faculty)
  { id: '31', name: 'Dr. Vijay Mishra', department: 'Civil', subject: 'Structural Analysis', cabin: 'CE-401', username: 'vijay', password: 'pass123', timetable: [] },
  { id: '32', name: 'Prof. Madhuri Kamath', department: 'Civil', subject: 'Transportation', cabin: 'CE-402', username: 'madhuri', password: 'pass123', timetable: [] },
  { id: '33', name: 'Dr. Harish Pandey', department: 'Civil', subject: 'Geotechnical Engineering', cabin: 'CE-403', username: 'harish', password: 'pass123', timetable: [] },
  { id: '34', name: 'Prof. Yamini Pai', department: 'Civil', subject: 'Construction Management', cabin: 'CE-404', username: 'yamini', password: 'pass123', timetable: [] },
  { id: '35', name: 'Dr. Naveen Choudhary', department: 'Civil', subject: 'Concrete Technology', cabin: 'CE-405', username: 'naveen', password: 'pass123', timetable: [] },
  { id: '36', name: 'Prof. Swati Dubey', department: 'Civil', subject: 'Environmental Engineering', cabin: 'CE-406', username: 'swati', password: 'pass123', timetable: [] },
  { id: '37', name: 'Dr. Santosh Bhandari', department: 'Civil', subject: 'Surveying', cabin: 'CE-407', username: 'santosh', password: 'pass123', timetable: [] },
  { id: '38', name: 'Prof. Nisha Kapoor', department: 'Civil', subject: 'Hydraulics', cabin: 'CE-408', username: 'nisha', password: 'pass123', timetable: [] },
  { id: '39', name: 'Dr. Alok Tripathi', department: 'Civil', subject: 'Steel Structures', cabin: 'CE-409', username: 'alok', password: 'pass123', timetable: [] },
  { id: '40', name: 'Prof. Vaishali Saxena', department: 'Civil', subject: 'Water Resources', cabin: 'CE-410', username: 'vaishali', password: 'pass123', timetable: [] },

  // Mathematics Department (5 faculty)
  { id: '41', name: 'Dr. Subhash Rao', department: 'Mathematics', subject: 'Calculus', cabin: 'MA-501', username: 'subhash', password: 'pass123', timetable: [] },
  { id: '42', name: 'Prof. Smita Kulkarni', department: 'Mathematics', subject: 'Linear Algebra', cabin: 'MA-502', username: 'smita', password: 'pass123', timetable: [] },
  { id: '43', name: 'Dr. Ganesh Iyer', department: 'Mathematics', subject: 'Differential Equations', cabin: 'MA-503', username: 'ganesh', password: 'pass123', timetable: [] },
  { id: '44', name: 'Prof. Anita Rawat', department: 'Mathematics', subject: 'Probability Theory', cabin: 'MA-504', username: 'anita', password: 'pass123', timetable: [] },
  { id: '45', name: 'Dr. Mahesh Tiwari', department: 'Mathematics', subject: 'Numerical Methods', cabin: 'MA-505', username: 'mahesh', password: 'pass123', timetable: [] },

  // Physics Department (5 faculty)
  { id: '46', name: 'Dr. Ranjit Singh', department: 'Physics', subject: 'Quantum Mechanics', cabin: 'PH-601', username: 'ranjit', password: 'pass123', timetable: [] },
  { id: '47', name: 'Prof. Leela Menon', department: 'Physics', subject: 'Electromagnetism', cabin: 'PH-602', username: 'leela', password: 'pass123', timetable: [] },
  { id: '48', name: 'Dr. Arun Malhotra', department: 'Physics', subject: 'Optics', cabin: 'PH-603', username: 'arun', password: 'pass123', timetable: [] },
  { id: '49', name: 'Prof. Pallavi Jha', department: 'Physics', subject: 'Modern Physics', cabin: 'PH-604', username: 'pallavi', password: 'pass123', timetable: [] },
  { id: '50', name: 'Dr. Nitin Bhatt', department: 'Physics', subject: 'Solid State Physics', cabin: 'PH-605', username: 'nitin', password: 'pass123', timetable: [] },
];

// Initialize faculty data in localStorage
export function initializeFacultyData() {
  const stored = localStorage.getItem('facultyData');
  if (!stored) {
    localStorage.setItem('facultyData', JSON.stringify(INITIAL_FACULTY));
  }
}

export function getFacultyData(): Faculty[] {
  const stored = localStorage.getItem('facultyData');
  return stored ? JSON.parse(stored) : INITIAL_FACULTY;
}

export function saveFacultyData(data: Faculty[]) {
  localStorage.setItem('facultyData', JSON.stringify(data));
}

export function updateFacultyTimetable(facultyId: string, timetable: TimeSlot[]) {
  const allFaculty = getFacultyData();
  const updated = allFaculty.map(f =>
    f.id === facultyId ? { ...f, timetable } : f
  );
  saveFacultyData(updated);
}

export function updateFacultyCabin(facultyId: string, cabin: string) {
  const allFaculty = getFacultyData();
  const updated = allFaculty.map(f =>
    f.id === facultyId ? { ...f, cabin } : f
  );
  saveFacultyData(updated);
}

export function getCurrentStatus(faculty: Faculty): { status: string; details?: string } {
  const now = new Date();
  const currentDay = DAYS[now.getDay() - 1]; // Monday = 0
  const currentTime = now.getHours() * 60 + now.getMinutes(); // Minutes since midnight

  if (!currentDay || now.getDay() === 0) {
    return { status: 'Available' };
  }

  const currentClass = faculty.timetable.find(slot => {
    if (slot.day !== currentDay) return false;

    const [startHour, startMin] = slot.startTime.split(':').map(Number);
    const [endHour, endMin] = slot.endTime.split(':').map(Number);
    const startMinutes = startHour * 60 + startMin;
    const endMinutes = endHour * 60 + endMin;

    return currentTime >= startMinutes && currentTime < endMinutes;
  });

  if (currentClass) {
    return {
      status: 'In Class',
      details: `${currentClass.subject} - Room ${currentClass.classroom}`
    };
  }

  return { status: 'Available' };
}

export function loginFaculty(username: string, password: string): Faculty | null {
  const allFaculty = getFacultyData();
  return allFaculty.find(f => f.username === username && f.password === password) || null;
}
