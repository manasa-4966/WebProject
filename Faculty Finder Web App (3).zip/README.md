
  # Faculty Finder Web App

  This is a code bundle for Faculty Finder Web App. The original project is available at https://www.figma.com/design/b5gatvrnu0Fb3aOwI3biPf/Faculty-Finder-Web-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  